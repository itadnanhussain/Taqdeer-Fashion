/*=========================================================
        TAQDEER FASHION
        PRODUCT CARD COMPONENT v3
=========================================================*/


"use strict";





function createProductCard(product){



const card =
document.createElement(
"div"
);



card.className =
"product-card";



card.dataset.id =
product.id;







card.innerHTML = `


<div class="product-image">


${
product.badge
?
`
<span class="sale-badge">
${product.badge}
</span>
`
:
""
}



<button

class="wishlist-btn"

data-id="${product.id}">

<i data-lucide="heart"></i>

</button>





<img

src="${product.image || '../../assets/placeholders/product.jpg'}"

alt="${product.name}">



</div>







<div class="product-info">



<span class="product-category">

${product.category || "Fashion"}

</span>





<h3>

${product.name}

</h3>







<div class="product-rating">


<span>
★★★★★
</span>


<span>

${product.rating || 5}

</span>


</div>







<div class="product-price">


<span class="current">

৳${product.price || 0}

</span>


${
product.oldPrice
?
`
<span class="old">

৳${product.oldPrice}

</span>
`
:
""

}


</div>







<div class="product-actions">


<button

class="add-cart-btn"

data-id="${product.id}">


Add To Cart


</button>





<button

class="quick-view-btn"

data-id="${product.id}">


Quick View


</button>



</div>





</div>



`;








/*=========================================
        CARD CLICK
=========================================*/


card.addEventListener(
"click",
(e)=>{



if(
e.target.closest(".add-cart-btn")
||
e.target.closest(".wishlist-btn")
||
e.target.closest(".quick-view-btn")
){

return;

}




window.location.href =

`../product-details/index.html?id=${product.id}`;



});






return card;



}









/*=========================================
        PRODUCT EVENTS
=========================================*/


document.addEventListener(
"click",
async(e)=>{





/* WISHLIST */


const wishlistBtn =
e.target.closest(
".wishlist-btn"
);



if(wishlistBtn){



const id =
wishlistBtn.dataset.id;




const product =
await window.ProductService
.getProductById(id);




if(product){



let wishlist =
JSON.parse(
localStorage.getItem(
"taqdeerWishlist"
)
)
||
[];




const exists =
wishlist.find(
item =>
item.id === product.id
);




if(!exists){


wishlist.push(product);



localStorage.setItem(
"taqdeerWishlist",
JSON.stringify(wishlist)
);



showToast(
"Added to wishlist"
);



}
else{


showToast(
"Already in wishlist"
);


}



}



return;



}







/* QUICK VIEW */


const quickBtn =
e.target.closest(
".quick-view-btn"
);



if(quickBtn){



const id =
quickBtn.dataset.id;



window.location.href =

`../product-details/index.html?id=${id}`;



return;


}








/* ADD CART */


const cartBtn =
e.target.closest(
".add-cart-btn"
);





if(!cartBtn)
return;





const id =
cartBtn.dataset.id;





const product =
await window.ProductService
.getProductById(id);





if(product){



window.CartService
.addToCart(product);





showToast(
"Product added to cart"
);



}




});









/*=========================================
        TOAST
=========================================*/


function showToast(message){



let toast =
document.querySelector(
".toast"
);





if(!toast){


toast =
document.createElement(
"div"
);


toast.className =
"toast";


document.body
.appendChild(toast);


}





toast.innerText =
message;




toast.classList
.add("show");





setTimeout(
()=>{


toast.classList
.remove("show");


},
2500
);



}









window.createProductCard =
createProductCard;
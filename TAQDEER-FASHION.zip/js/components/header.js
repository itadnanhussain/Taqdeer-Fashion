/*=========================================================
                TAQDEER FASHION
                HEADER COMPONENT
=========================================================*/


"use strict";



/*=========================================
            SELECTORS
=========================================*/


const header =
document.querySelector(".header");


const hamburger =
document.querySelector(".hamburger");


const mobileMenu =
document.querySelector(".mobile-menu");


const mobileLinks =
document.querySelectorAll(".mobile-menu a");


const searchButton =
document.querySelector(".search-btn");


const searchModal =
document.querySelector(".search-modal");


const searchClose =
document.querySelector(".search-close");


const searchInput =
document.querySelector(".search-box input");


const cartButton =
document.querySelector(".cart-btn");


const cartDrawer =
document.querySelector(".cart-drawer");


const cartClose =
document.querySelector(".cart-close");





/*=========================================
            BODY LOCK
=========================================*/


function lockBody(){

    document.body.style.overflow="hidden";

}



function unlockBody(){

    document.body.style.overflow="";

}







/*=========================================
            STICKY HEADER
=========================================*/


if(header){


window.addEventListener("scroll",()=>{


    header.classList.toggle(
        "scrolled",
        window.scrollY > 80
    );


});


}







/*=========================================
            MOBILE MENU
=========================================*/


function closeMobileMenu(){


    if(mobileMenu){

        mobileMenu.classList.remove("active");

        unlockBody();

    }


}



if(hamburger && mobileMenu){


hamburger.addEventListener("click",()=>{


    const active =
    mobileMenu.classList.toggle("active");


    active
    ? lockBody()
    : unlockBody();


});


}



mobileLinks.forEach(link=>{


    link.addEventListener(
        "click",
        closeMobileMenu
    );


});







/*=========================================
            SEARCH MODAL
=========================================*/


function openSearch(){


    if(searchModal){


        searchModal.classList.add("active");


        lockBody();


        setTimeout(()=>{


            if(searchInput){

                searchInput.focus();

            }


        },300);


    }


}



function closeSearch(){


    if(searchModal){


        searchModal.classList.remove("active");


        unlockBody();


    }


}



if(searchButton){

    searchButton.addEventListener(
        "click",
        openSearch
    );

}



if(searchClose){

    searchClose.addEventListener(
        "click",
        closeSearch
    );

}







/*=========================================
            CART DRAWER
=========================================*/


function openCart(){


    if(cartDrawer){


        cartDrawer.classList.add("active");


        lockBody();


    }


}



function closeCart(){


    if(cartDrawer){


        cartDrawer.classList.remove("active");


        unlockBody();


    }


}



if(cartButton){

    cartButton.addEventListener(
        "click",
        openCart
    );

}



if(cartClose){

    cartClose.addEventListener(
        "click",
        closeCart
    );

}







/*=========================================
            ESC CLOSE
=========================================*/


document.addEventListener(
"keydown",
(e)=>{


    if(e.key==="Escape"){


        closeMobileMenu();

        closeSearch();

        closeCart();


    }


});







/*=========================================
        OUTSIDE CLICK CLOSE
=========================================*/


document.addEventListener(
"click",
(e)=>{


    if(
        mobileMenu &&
        hamburger &&
        !mobileMenu.contains(e.target) &&
        !hamburger.contains(e.target)
    ){

        closeMobileMenu();

    }



});

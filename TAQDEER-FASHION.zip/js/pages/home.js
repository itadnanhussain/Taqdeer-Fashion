/*=========================================================
                TAQDEER FASHION
                HOME PAGE SCRIPT
=========================================================*/


"use strict";



document.addEventListener(
"DOMContentLoaded",
()=>{





/*=========================================
            PAGE LOADER
=========================================*/


const loader =
document.querySelector(".page-loader");


if(loader){


    window.addEventListener(
        "load",
        ()=>{


            setTimeout(()=>{


                loader.style.opacity="0";


                setTimeout(()=>{

                    loader.remove();

                },500);


            },500);


        }
    );


}







/*=========================================
            HERO SLIDER READY
=========================================*/


const heroSlides =
document.querySelectorAll(".hero-slide");


const heroDots =
document.querySelectorAll(".hero-dot");


let currentSlide = 0;



function showSlide(index){


    if(!heroSlides.length)
        return;



    heroSlides.forEach(
    slide=>{

        slide.classList.remove("active");

    });



    heroDots.forEach(
    dot=>{

        dot.classList.remove("active");

    });



    heroSlides[index]
    .classList.add("active");



    if(heroDots[index]){

        heroDots[index]
        .classList.add("active");

    }


}



function nextSlide(){


    currentSlide++;


    if(
        currentSlide >= heroSlides.length
    ){

        currentSlide = 0;

    }


    showSlide(currentSlide);


}



if(heroSlides.length > 1){


    setInterval(
        nextSlide,
        5000
    );


}







/*=========================================
            SCROLL REVEAL
=========================================*/


const revealElements =
document.querySelectorAll(
".reveal"
);



const revealObserver =
new IntersectionObserver(
(entries)=>{


    entries.forEach(
    entry=>{


        if(entry.isIntersecting){


            entry.target
            .classList.add("active");


        }


    });


},
{
    threshold:.15
}
);



revealElements.forEach(
element=>{


    revealObserver.observe(element);


});







/*=========================================
            BACK TO TOP
=========================================*/


const backTop =
document.querySelector(".back-top");



if(backTop){


window.addEventListener(
"scroll",
()=>{


    if(window.scrollY > 500){


        backTop
        .classList.add("active");


    }

    else{


        backTop
        .classList.remove("active");


    }


});



backTop.addEventListener(
"click",
()=>{


    window.scrollTo({

        top:0,

        behavior:"smooth"

    });


});


}







/*=========================================
            NUMBER COUNTER
=========================================*/


const counters =
document.querySelectorAll(
".counter"
);



counters.forEach(
counter=>{


    const target =
    Number(
        counter.dataset.count
    );



    let count = 0;



    const updateCounter = ()=>{


        const increment =
        Math.ceil(target / 100);



        count += increment;



        if(count < target){


            counter.innerText =
            count;


            requestAnimationFrame(
                updateCounter
            );


        }

        else{


            counter.innerText =
            target + "+";


        }


    };



    updateCounter();



});







/*=========================================
            CATEGORY LINKS
=========================================*/


const categoryCards =
document.querySelectorAll(
".category-card"
);



categoryCards.forEach(
card=>{


    card.addEventListener(
        "mouseenter",
        ()=>{


            card.classList.add(
                "hovered"
            );


        }
    );


    card.addEventListener(
        "mouseleave",
        ()=>{


            card.classList.remove(
                "hovered"
            );


        }
    );


});







/*=========================================
        FUTURE FIREBASE PRODUCTS HOOK
=========================================*/


window.TaqdeerHome = {


    refreshProducts(){

        console.log(
        "Firebase products ready hook"
        );


    },


    refreshCategories(){

        console.log(
        "Firebase categories ready hook"
        );


    }


};





});
/*=========================================================
        TAQDEER FASHION
        PRODUCT DETAILS SYSTEM v2
=========================================================*/

"use strict";


document.addEventListener(
"DOMContentLoaded",
async()=>{



let selectedProduct = null;

let quantity = 1;

let selectedSize = "M";





/*=========================================
        PRODUCT ID
=========================================*/


const params =
new URLSearchParams(
window.location.search
);


const productId =
params.get("id");





if(!productId){

console.error(
"Product ID Missing"
);

return;

}









/*=========================================
        DOM
=========================================*/


const mainImage =
document.getElementById(
"main-product-image"
);


const productCategory =
document.getElementById(
"product-category"
);


const productName =
document.getElementById(
"product-name"
);


const productPrice =
document.getElementById(
"product-price"
);


const productDescription =
document.getElementById(
"product-description"
);


const quantityValue =
document.getElementById(
"quantity-value"
);


const decreaseQty =
document.getElementById(
"decrease-qty"
);


const increaseQty =
document.getElementById(
"increase-qty"
);


const addToCartBtn =
document.getElementById(
"add-to-cart"
);


const buyNowBtn =
document.getElementById(
"buy-now"
);









/*=========================================
        LOAD PRODUCT
=========================================*/


async function loadProduct(){


try{


selectedProduct =
await window.ProductService
.getProductById(
productId
);





if(!selectedProduct){


console.error(
"Product not found"
);


return;


}







if(mainImage){


mainImage.src =
selectedProduct.image ||
"../../assets/placeholders/product.jpg";


mainImage.alt =
selectedProduct.name;


}







if(productCategory){


productCategory.innerText =
selectedProduct.category ||
"Fashion";


}





if(productName){


productName.innerText =
selectedProduct.name;


}






if(productPrice){


productPrice.innerText =
`৳${selectedProduct.price}`;


}







if(productDescription){


productDescription.innerText =
selectedProduct.description ||
"Premium quality product from Taqdeer Fashion";


}





}



catch(error){


console.error(
"Product Load Error:",
error
);


}



}









/*=========================================
        QUANTITY
=========================================*/


if(decreaseQty){


decreaseQty.addEventListener(
"click",
()=>{


if(quantity > 1){


quantity--;


quantityValue.innerText =
quantity;


}


});


}





if(increaseQty){


increaseQty.addEventListener(
"click",
()=>{


quantity++;


quantityValue.innerText =
quantity;



});


}









/*=========================================
        SIZE
=========================================*/


document
.querySelectorAll(
".size-btn"
)
.forEach(
button=>{


button.addEventListener(
"click",
()=>{


document
.querySelectorAll(
".size-btn"
)
.forEach(
btn=>
btn.classList.remove(
"active"
)
);



button.classList.add(
"active"
);



selectedSize =
button.innerText;



});


});









/*=========================================
        ADD TO CART
=========================================*/


if(addToCartBtn){


addToCartBtn.addEventListener(
"click",
()=>{


if(!selectedProduct)
return;



const product = {


...selectedProduct,

quantity,

size:selectedSize


};



window.CartService
.addToCart(
product
);



alert(
"Product added to cart"
);



});


}









/*=========================================
        BUY NOW
=========================================*/


if(buyNowBtn){


buyNowBtn.addEventListener(
"click",
()=>{


if(!selectedProduct)
return;



const product = {


...selectedProduct,


quantity,


size:selectedSize


};





localStorage.setItem(

"taqdeerCart",

JSON.stringify(
[
product
]

)

);





window.location.href =
"../checkout/index.html";



});


}








loadProduct();




});
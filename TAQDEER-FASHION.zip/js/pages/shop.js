/*=========================================================
                TAQDEER FASHION
                SHOP PAGE SCRIPT
=========================================================*/

let shopProducts = [];
"use strict";









/*=========================================
        STATE
=========================================*/


let currentCategory = "all";

let currentSearch = "";

let currentSort = "default";

let visibleCount = 8;





/*=========================================
        DOM ELEMENTS
=========================================*/


const shopProductsGrid =
document.getElementById(
"shopProductsGrid"
);


const shopSearchInput =
document.getElementById(
"shopSearchInput"
);


const sortSelect =
document.getElementById(
"sortSelect"
);


const categoryButtons =
document.querySelectorAll(
".shop-category-btn"
);


const productCount =
document.getElementById(
"productCount"
);


const shopEmpty =
document.getElementById(
"shopEmpty"
);


const loadMoreBtn =
document.getElementById(
"loadMoreBtn"
);





/*=========================================
        PRODUCT SERVICE FOR CARD COMPONENT
=========================================*/








/*=========================================
        FILTER PRODUCTS
=========================================*/


function getFilteredProducts(){


    let products =
    [...shopProducts];



    if(currentCategory !== "all"){

        products =
        products.filter(
            product =>
            product.category === currentCategory
        );

    }



    if(currentSearch.trim() !== ""){

        const keyword =
        currentSearch
        .toLowerCase()
        .trim();



        products =
        products.filter(
            product =>
            product.name
            .toLowerCase()
            .includes(keyword)
            ||
            product.category
            .toLowerCase()
            .includes(keyword)
        );

    }



    if(currentSort === "low-high"){

        products.sort(
            (a,b)=>
            a.price - b.price
        );

    }



    if(currentSort === "high-low"){

        products.sort(
            (a,b)=>
            b.price - a.price
        );

    }



    if(currentSort === "newest"){

        products.reverse();

    }



    return products;


}





/*=========================================
        RENDER PRODUCTS
=========================================*/


function renderProducts(){


    if(!shopProductsGrid)
        return;



    const filteredProducts =
    getFilteredProducts();



    const visibleProducts =
    filteredProducts.slice(
        0,
        visibleCount
    );



    shopProductsGrid.innerHTML =
    "";



    if(productCount){

        productCount.innerText =
        `${filteredProducts.length} products found`;

    }



    if(filteredProducts.length === 0){

        if(shopEmpty){

            shopEmpty.classList.add(
                "active"
            );

        }


        if(loadMoreBtn){

            loadMoreBtn.classList.add(
                "hidden"
            );

        }


        return;

    }



    if(shopEmpty){

        shopEmpty.classList.remove(
            "active"
        );

    }



    visibleProducts.forEach(
        product => {


            if(window.createProductCard){

                const card =
                window.createProductCard(
                    product
                );


                shopProductsGrid.appendChild(
                    card
                );

            }


        }
    );



    if(loadMoreBtn){

        if(visibleCount >= filteredProducts.length){

            loadMoreBtn.classList.add(
                "hidden"
            );

        }

        else{

            loadMoreBtn.classList.remove(
                "hidden"
            );

        }

    }



    if(window.lucide){

        lucide.createIcons();

    }


}





/*=========================================
        CATEGORY FILTER
=========================================*/


categoryButtons.forEach(
button => {


    button.addEventListener(
        "click",
        ()=>{


            categoryButtons.forEach(
                btn =>
                btn.classList.remove(
                    "active"
                )
            );



            button.classList.add(
                "active"
            );



            currentCategory =
            button.dataset.category;



            visibleCount =
            8;



            renderProducts();


        }
    );


});





/*=========================================
        SEARCH
=========================================*/


if(shopSearchInput){


    shopSearchInput.addEventListener(
        "input",
        ()=>{


            currentSearch =
            shopSearchInput.value;



            visibleCount =
            8;



            renderProducts();


        }
    );


}





/*=========================================
        SORT
=========================================*/


if(sortSelect){


    sortSelect.addEventListener(
        "change",
        ()=>{


            currentSort =
            sortSelect.value;



            visibleCount =
            8;



            renderProducts();


        }
    );


}





/*=========================================
        LOAD MORE
=========================================*/


if(loadMoreBtn){


    loadMoreBtn.addEventListener(
        "click",
        ()=>{


            visibleCount +=
            4;



            renderProducts();


        }
    );


}





/*=========================================
        INIT
=========================================*/


document.addEventListener(
"DOMContentLoaded",
async()=>{


    shopProducts =
    await window.ProductService.getProducts();


    renderProducts();


});
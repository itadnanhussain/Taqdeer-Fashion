/*=========================================================
        TAQDEER FASHION
        LOGIN SYSTEM
=========================================================*/


"use strict";


document.addEventListener(
"DOMContentLoaded",
()=>{


const loginForm =
document.getElementById(
"login-form"
);


const googleBtn =
document.getElementById(
"google-login"
);


const message =
document.getElementById(
"auth-message"
);






function showMessage(
text,
type="error"
){


if(!message)
return;


message.innerText =
text;


message.className =
type === "success"
?
"auth-success"
:
"auth-error";


}







async function redirectUser(
user
){


try{


const userDoc =
await window.db
.collection("users")
.doc(user.uid)
.get();




if(!userDoc.exists){


window.location.href =
"../account/index.html";


return;


}





const userData =
userDoc.data();





console.log(
"User Role:",
userData.role
);





if(
userData.role === "admin"
){


window.location.href =
"../admin/index.html";


}

else{


window.location.href =
"../account/index.html";


}



}



catch(error){


console.error(
"Redirect Error:",
error
);


window.location.href =
"../account/index.html";


}


}









/*==============================
        EMAIL LOGIN
==============================*/


if(loginForm){


loginForm.addEventListener(
"submit",
async(e)=>{


e.preventDefault();



const email =
document
.getElementById(
"login-email"
)
.value
.trim();



const password =
document
.getElementById(
"login-password"
)
.value;





try{


const user =
await window.AuthService
.loginUser(
email,
password
);





showMessage(
"Login Successful",
"success"
);





redirectUser(user);



}



catch(error){


showMessage(
error.message
);


}



});


}









/*==============================
        GOOGLE LOGIN
==============================*/


if(googleBtn){


googleBtn.addEventListener(
"click",
async()=>{


try{


const user =
await window.AuthService
.googleLogin();





showMessage(
"Google Login Successful",
"success"
);





setTimeout(()=>{


redirectUser(
user
);



},500);



}



catch(error){


console.error(
error
);


showMessage(
error.message
);



}



});


}



});
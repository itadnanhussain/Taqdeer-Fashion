/*=========================================================
            TAQDEER FASHION
            ACCOUNT SYSTEM v3
=========================================================*/


"use strict";



document.addEventListener(
"DOMContentLoaded",
()=>{





const userName =
document.getElementById(
"user-name"
);



const userEmail =
document.getElementById(
"user-email"
);



const userPhoto =
document.getElementById(
"user-photo"
);



const logoutBtn =
document.getElementById(
"logout-btn"
);









/*=========================================
        LOAD USER
=========================================*/


function loadUser(){



if(
!window.auth ||
!window.db
){

console.error(
"Firebase not ready"
);

return;

}






window.auth.onAuthStateChanged(
async(user)=>{





console.log(
"Auth User:",
user
);






if(!user){

    console.log(
        "Waiting for auth..."
    );

    return;

}







try{



const userRef =
window.db
.collection("users")
.doc(user.uid);




const snapshot =
await userRef.get();





const userData =
snapshot.exists
?
snapshot.data()
:
{};








if(userName){


userName.innerText =

userData.name ||

user.displayName ||

"Taqdeer Customer";


}







if(userEmail){


userEmail.innerText =

user.email;


}







if(userPhoto){


userPhoto.src =

user.photoURL ||

userData.photo ||

"../../assets/logos/logo-1.png";


}





}



catch(error){



console.error(
"Profile Error:",
error
);


}




});



}









/*=========================================
            LOGOUT
=========================================*/


if(logoutBtn){



logoutBtn.addEventListener(
"click",
async()=>{


try{


await window.auth
.signOut();




window.location.href =
"../auth/login.html";



}


catch(error){


console.error(
"Logout Error:",
error
);


}



});



}










/*=========================================
            INIT
=========================================*/


loadUser();





if(window.lucide){


lucide.createIcons();


}



});
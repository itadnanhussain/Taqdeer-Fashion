/*=========================================================
        TAQDEER FASHION
        ADMIN ORDER MANAGEMENT v2
=========================================================*/


"use strict";


document.addEventListener(
"DOMContentLoaded",
()=>{


const ordersContainer =
document.querySelector(
"#admin-orders-list"
);



/*=========================================
        STATUS STYLE
=========================================*/


function statusClass(status){

    return status
    ?
    status.toLowerCase()
    :
    "pending";

}





/*=========================================
        LOAD ORDERS
=========================================*/


async function loadOrders(){


try{


const snapshot =
await window.db
.collection("orders")
.orderBy(
"createdAt",
"desc"
)
.get();




const orders =
snapshot.docs.map(doc=>{


return {

id:doc.id,

...doc.data()

};


});



renderOrders(orders);



}

catch(error){

console.error(
"Admin Orders Error:",
error
);


}



}







/*=========================================
        RENDER
=========================================*/


function renderOrders(orders){



if(!ordersContainer)
return;



ordersContainer.innerHTML="";




if(!orders.length){

ordersContainer.innerHTML=`

<div class="empty-orders">

<h3>
No Orders Found
</h3>

</div>

`;

return;

}






orders.forEach(order=>{



const card =
document.createElement(
"div"
);



card.className =
"admin-order-card";




card.innerHTML = `


<div class="order-top">


<div>

<h3>
#${order.id}
</h3>

<p>
${order.customer?.name || "Guest"}
</p>

</div>



<span class="status ${statusClass(order.status)}">

${order.status || "Pending"}

</span>


</div>





<div class="order-info">


<p>
📦 Items:
${order.items?.length || 0}
</p>


<p>
💳 ${order.paymentMethod || "COD"}
</p>


<strong>
৳${order.total || 0}
</strong>


</div>






<div class="order-actions">


<select 
class="order-status-select"
data-id="${order.id}">


<option value="pending">
Pending
</option>

<option value="confirmed">
Confirmed
</option>

<option value="processing">
Processing
</option>

<option value="shipped">
Shipped
</option>

<option value="delivered">
Delivered
</option>

<option value="cancelled">
Cancelled
</option>


</select>




<button
class="view-order"
data-id="${order.id}">

View

</button>



</div>



`;



ordersContainer
.appendChild(card);



});



}





/*=========================================
        UPDATE STATUS
=========================================*/


document.addEventListener(
"change",
async(e)=>{


if(
e.target.classList
.contains(
"order-status-select"
)

){



const id =
e.target.dataset.id;


const status =
e.target.value;




await window.db
.collection("orders")
.doc(id)
.update({

status,

updatedAt:
new Date()

});



alert(
"Order status updated"
);



}


});







loadOrders();



});
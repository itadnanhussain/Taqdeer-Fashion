/*=========================================================
                TAQDEER FASHION
                USER ORDERS SYSTEM v2
=========================================================*/


"use strict";


document.addEventListener(
"DOMContentLoaded",
()=>{


const ordersContainer =
document.querySelector(
".orders-container"
);






/*=========================================
        STATUS CLASS
=========================================*/


function getStatusClass(status){


return status
?
status.toLowerCase()
:
"pending";


}






/*=========================================
        FORMAT DATE
=========================================*/


function formatDate(date){


if(!date)
return "";



return new Date(date)
.toLocaleDateString(
"en-US",
{
year:"numeric",
month:"short",
day:"numeric"
}
);


}







/*=========================================
        RENDER ORDERS
=========================================*/


function renderOrders(orders){



if(!ordersContainer)
return;




ordersContainer.innerHTML="";





if(!orders.length){


ordersContainer.innerHTML=`

<div class="empty-orders">

<h3>
No Orders Found
</h3>


<p>
Start shopping from Taqdeer Fashion
</p>


</div>

`;

return;


}






orders.forEach(order=>{



const status =
order.status || "Pending";




const card =
document.createElement(
"div"
);



card.className =
"order-card";





card.innerHTML=`


<div class="order-card-header">


<div>

<h3>

Order #${order.id}

</h3>


<small>

${formatDate(order.createdAt)}

</small>


</div>





<span class="order-status ${getStatusClass(status)}">

${status}

</span>



</div>






<div class="order-card-body">


<p>

📦 Items:
${order.items?.length || 0}

</p>



<p>

💳 Payment:
${order.paymentMethod || "COD"}

</p>





<strong>

Total:
৳${order.total || 0}

</strong>



</div>







<div class="order-mini-timeline">


<span class="${status !== "cancelled" ? "active":""}">
Placed
</span>


<span class="${
["processing","shipped","delivered"].includes(status)
?"active":""
}">
Processing
</span>


<span class="${
["shipped","delivered"].includes(status)
?"active":""
}">
Shipped
</span>


<span class="${
status==="delivered"
?"active":""
}">
Delivered
</span>



</div>







<a 
href="details.html?id=${order.id}"
class="success-btn">


View Details


</a>



`;




ordersContainer
.appendChild(card);



});



}









/*=========================================
        LOAD ORDERS
=========================================*/


async function loadOrders(){


try{


if(!window.auth || !window.db){

console.error(
"Firebase not ready"
);

return;

}




window.auth.onAuthStateChanged(
async(user)=>{


if(!user){

ordersContainer.innerHTML=`

<p>
Please login to view orders
</p>

`;

return;

}





const snapshot =
await window.db
.collection("orders")
.where(
"userId",
"==",
user.uid
)
.orderBy(
"createdAt",
"desc"
)
.get();





const orders =
snapshot.docs.map(
doc=>{


return {

id:doc.id,

...doc.data()

};


});





renderOrders(orders);



});


}


catch(error){


console.error(
"Orders loading error:",
error
);


}



}






loadOrders();





});
/*=========================================================
                TAQDEER FASHION
                ORDER SUCCESS PAGE
=========================================================*/


"use strict";



document.addEventListener(
"DOMContentLoaded",
()=>{





/*=========================================
        GET ORDER ID FROM URL
=========================================*/


const params =
new URLSearchParams(
window.location.search
);



const orderId =
params.get("id");





const orderIdElement =
document.querySelector(
"#order-id"
);





if(!orderId){


    if(orderIdElement){

        orderIdElement.innerText =
        "Not Found";

    }


    return;


}







/*=========================================
        DISPLAY ORDER ID
=========================================*/


if(orderIdElement){


    orderIdElement.innerText =
    orderId;


}







/*=========================================
        FIRESTORE ORDER FETCH
=========================================*/


async function loadOrder(){


    try{


        if(!window.db){

            console.log(
            "Firebase not loaded"
            );

            return;

        }




        const orderDoc =
        await window.db
        .collection("orders")
        .doc(orderId)
        .get();






        if(orderDoc.exists){


            const order =
            orderDoc.data();



            console.log(
                "Order Details:",
                order
            );



            window.currentOrder =
            order;



        }



        else{


            console.log(
            "Order not found"
            );


        }



    }



    catch(error){


        console.error(
        "Order loading error:",
        error
        );


    }



}






loadOrder();







});
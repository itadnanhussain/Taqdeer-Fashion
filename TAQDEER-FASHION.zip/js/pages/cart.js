/*=========================================================
                TAQDEER FASHION
                CART PAGE SYSTEM v3
=========================================================*/


"use strict";



document.addEventListener(
"DOMContentLoaded",
()=>{





/*=========================================
            DOM
=========================================*/


const cartItems =
document.getElementById(
"cart-items"
);



const emptyCart =
document.getElementById(
"empty-cart"
);



const cartCount =
document.getElementById(
"cart-count"
);



const subtotalElement =
document.getElementById(
"subtotal"
);



const deliveryElement =
document.getElementById(
"delivery"
);



const totalElement =
document.getElementById(
"total"
);



const checkoutBtn =
document.getElementById(
"checkout-btn"
);









/*=========================================
            MONEY FORMAT
=========================================*/


function money(value){


return "৳" +
Number(value)
.toLocaleString();


}









/*=========================================
            RENDER CART
=========================================*/


function renderCart(){



if(!window.CartService)
return;





const cart =
window.CartService
.getCart();







if(!cartItems)
return;





cartItems.innerHTML="";






if(cart.length===0){



if(emptyCart){

emptyCart.classList
.add("active");

}




cartCount.innerText =
"0 Items";



subtotalElement.innerText =
money(0);



deliveryElement.innerText =
money(0);



totalElement.innerText =
money(0);



return;



}







if(emptyCart){

emptyCart.classList
.remove("active");

}







let subtotal = 0;







cart.forEach(
(item,index)=>{



subtotal +=
Number(item.price)
*
Number(item.quantity || 1);







const card =
document.createElement(
"div"
);



card.className =
"cart-item";






card.innerHTML = `


<div class="cart-item-image">


<img

src="${item.image || '../../assets/placeholders/product.jpg'}"

alt="${item.name}">


</div>





<div class="cart-item-info">



<h3>
${item.name}
</h3>



<p>
${item.category || "Fashion"}
</p>




<strong>

${money(item.price)}

</strong>





<div class="quantity-control">


<button

class="qty-minus"

data-id="${item.id}">

-

</button>





<span>

${item.quantity || 1}

</span>





<button

class="qty-plus"

data-id="${item.id}">

+

</button>



</div>





<button

class="remove-btn"

data-id="${item.id}">

Remove

</button>





</div>


`;





cartItems
.appendChild(card);



});









const delivery =
window.CartService
.getDeliveryCharge();





const total =
subtotal + delivery;






cartCount.innerText =
`${cart.length} Items`;




subtotalElement.innerText =
money(subtotal);




deliveryElement.innerText =
money(delivery);




totalElement.innerText =
money(total);





}









/*=========================================
            CART EVENTS
=========================================*/


document.addEventListener(
"click",
(e)=>{





const plus =
e.target.closest(
".qty-plus"
);





if(plus){



window.CartService
.increaseQuantity(
plus.dataset.id
);



renderCart();

return;


}








const minus =
e.target.closest(
".qty-minus"
);






if(minus){



window.CartService
.decreaseQuantity(
minus.dataset.id
);



renderCart();

return;


}








const remove =
e.target.closest(
".remove-btn"
);





if(remove){



window.CartService
.removeFromCart(
remove.dataset.id
);



renderCart();

return;


}





});









/*=========================================
            CHECKOUT
=========================================*/


if(checkoutBtn){



checkoutBtn.addEventListener(
"click",
()=>{





const cart =
window.CartService
.getCart();






if(cart.length===0){


alert(
"Your cart is empty"
);


return;


}







const user =
window.auth
?
window.auth.currentUser
:
null;







if(!user){


window.location.href =
"../auth/login.html";


return;


}







window.location.href =
"../checkout/index.html";





});


}









/*=========================================
            INIT
=========================================*/


renderCart();





window.CartUI = {


renderCart


};





});
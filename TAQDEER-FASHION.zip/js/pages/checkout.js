/*=========================================================
        TAQDEER FASHION
        CHECKOUT SYSTEM v3
=========================================================*/


"use strict";


document.addEventListener(
"DOMContentLoaded",
()=>{



const checkoutItems =
document.querySelector(
".checkout-items"
);



const subtotalElement =
document.querySelector(
"#checkout-subtotal"
);



const deliveryElement =
document.querySelector(
"#checkout-delivery"
);



const totalElement =
document.querySelector(
"#checkout-total"
);



const checkoutForm =
document.querySelector(
"#checkout-form"
);




let selectedPayment =
"COD";








/*=========================================
        PAYMENT
=========================================*/


document
.querySelectorAll(
"input[name='payment']"
)
.forEach(
input=>{


input.addEventListener(
"change",
()=>{


selectedPayment =
input.value;



});



});









/*=========================================
        LOAD CART
=========================================*/


function loadCheckout(){



if(!window.CartService)
return;




const cart =
window.CartService
.getCart();





if(!checkoutItems)
return;



checkoutItems.innerHTML="";





if(cart.length===0){



checkoutItems.innerHTML=

`

<div class="empty-checkout">

<h3>
Cart is empty
</h3>

<p>
Please add products first
</p>

</div>

`;

return;


}







cart.forEach(
item=>{


const div =
document.createElement(
"div"
);



div.className =
"checkout-item";




div.innerHTML=

`

<img
src="${item.image || '../../assets/placeholders/product.jpg'}"
alt="${item.name}"
>


<div>

<h4>
${item.name}
</h4>

<p>
Qty: ${item.quantity}
</p>

</div>


<strong>
৳${item.price * item.quantity}
</strong>

`;




checkoutItems
.appendChild(div);



});





updateTotal();



}









/*=========================================
        TOTAL
=========================================*/


function updateTotal(){


const subtotal =
window.CartService
.getCartTotal();



const delivery =
window.CartService
.getDeliveryCharge();



const total =
window.CartService
.getGrandTotal();





if(subtotalElement)

subtotalElement.innerText =
"৳"+subtotal;





if(deliveryElement)

deliveryElement.innerText =
"৳"+delivery;





if(totalElement)

totalElement.innerText =
"৳"+total;



}









/*=========================================
        PLACE ORDER
=========================================*/


if(checkoutForm){



checkoutForm.addEventListener(
"submit",
async(e)=>{


e.preventDefault();





const cart =
window.CartService
.getCart();





if(cart.length===0){


alert(
"Your cart is empty"
);


return;


}







const user =
window.auth.currentUser;



if(!user){


alert(
"Please login first"
);


window.location.href =
"../auth/login.html";


return;


}







const formData =
new FormData(
checkoutForm
);







const orderData = {


customer:{


name:
formData.get("name"),


phone:
formData.get("phone"),


email:
formData.get("email"),


address:
formData.get("address")

},





items:
cart,





paymentMethod:
selectedPayment,





subtotal:
window.CartService
.getCartTotal(),





delivery:
window.CartService
.getDeliveryCharge(),





total:
window.CartService
.getGrandTotal()



};








try{


const orderId =
await window.OrderService
.createOrder(
orderData
);





window.CartService
.clearCart();






alert(
"Order placed successfully"
);





window.location.href =
`../orders/success.html?id=${orderId}`;





}



catch(error){


console.error(
error
);



alert(
"Order failed"
);



}



});


}







loadCheckout();



});
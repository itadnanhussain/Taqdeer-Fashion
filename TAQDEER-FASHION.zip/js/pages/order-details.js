/*=========================================================
                TAQDEER FASHION
                ORDER DETAILS SYSTEM
=========================================================*/


"use strict";


document.addEventListener(
"DOMContentLoaded",
()=>{



const timelineSteps =
document.querySelectorAll(
".timeline-step"
);



const orderIdElement =
document.querySelector("#order-id");


const statusElement =
document.querySelector("#order-status");


const productsContainer =
document.querySelector("#order-products-list");


const customerName =
document.querySelector("#customer-name");


const customerPhone =
document.querySelector("#customer-phone");


const customerAddress =
document.querySelector("#customer-address");


const paymentMethod =
document.querySelector("#payment-method");


const orderTotal =
document.querySelector("#order-total");





/*=========================================
        UPDATE TIMELINE
=========================================*/


function updateTimeline(status){


const steps = [

"pending",
"processing",
"shipped",
"delivered"

];



timelineSteps.forEach(
step=>{

step.classList.remove(
"active"
);

});



const currentStatus =
status
?
status.toLowerCase()
:
"pending";



const currentIndex =
steps.indexOf(
currentStatus
);



if(currentIndex !== -1){


for(
let i=0;
i<=currentIndex;
i++
){


timelineSteps[i]
.classList.add(
"active"
);


}


}


}







/*=========================================
        GET ORDER ID
=========================================*/


const params =
new URLSearchParams(
window.location.search
);



const orderId =
params.get("id");





if(!orderId){

return;

}








/*=========================================
        LOAD ORDER
=========================================*/


async function loadOrder(){


try{


const order =
await window.OrderService
.getOrderById(orderId);





if(!order){


console.log(
"Order not found"
);


return;


}





renderOrder(order);



}


catch(error){


console.error(
"Order Details Error:",
error
);


}



}









/*=========================================
        RENDER ORDER
=========================================*/


function renderOrder(order){



if(orderIdElement){

orderIdElement.innerText =
order.id;

}





const status =
order.status || "pending";





if(statusElement){

statusElement.innerText =
status;

}





updateTimeline(status);








if(customerName){

customerName.innerText =
order.customer?.name || "";

}



if(customerPhone){

customerPhone.innerText =
order.customer?.phone || "";

}



if(customerAddress){

customerAddress.innerText =
order.customer?.address || "";

}





if(paymentMethod){

paymentMethod.innerText =
order.paymentMethod || "";

}





if(orderTotal){

orderTotal.innerText =
"৳" + (order.total || 0);

}






renderProducts(
order.items || []
);



}









/*=========================================
        PRODUCTS
=========================================*/


function renderProducts(items){


if(!productsContainer)
return;



productsContainer.innerHTML="";





items.forEach(item=>{


const product =
document.createElement(
"div"
);



product.className =
"order-product-item";





product.innerHTML = `


<div>


<h4>
${item.name}
</h4>


<p>
Quantity:
${item.quantity}
</p>


</div>




<strong>

৳${item.price * item.quantity}

</strong>



`;




productsContainer
.appendChild(product);



});



}







loadOrder();





});
/*=========================================================
                TAQDEER FASHION
                HOMEPAGE PRODUCTS
=========================================================*/


"use strict";



document.addEventListener(
"DOMContentLoaded",
()=>{



async function loadHomeProducts(){


    const containers =
    document.querySelectorAll(
        ".products-grid"
    );


    if(!containers.length){

        return;

    }



    const products =
    await window.ProductService
    .getProducts();




    if(!products.length){


        containers.forEach(container=>{


            container.innerHTML = `

            <p class="empty-message">
                No products available
            </p>

            `;


        });


        return;

    }





    containers.forEach(
    container=>{


        container.innerHTML="";



        products
        .slice(0,8)
        .forEach(product=>{


            const card =
            window.createProductCard(
                product
            );



            container.appendChild(card);



        });



    });





    if(window.lucide){

        window.lucide.createIcons();

    }



}







loadHomeProducts();



window.TaqdeerProducts={

    reload:
    loadHomeProducts

};



});
/*=========================================================
        TAQDEER FASHION
        ADMIN PRODUCT MANAGEMENT
        IMGBB VERSION
=========================================================*/


"use strict";


document.addEventListener(
"DOMContentLoaded",
()=>{



const productsList =
document.querySelector(
"#admin-products-list"
);


const addBtn =
document.querySelector(
"#add-product-btn"
);


const formSection =
document.querySelector(
"#product-form-section"
);


const form =
document.querySelector(
"#product-form"
);


const searchInput =
document.querySelector(
"#product-search"
);


const categoryFilter =
document.querySelector(
"#category-filter"
);


const stockFilter =
document.querySelector(
"#stock-filter"
);




let allProducts = [];

let editProductId = null;








/*==============================
        SHOW FORM
==============================*/


if(addBtn){


addBtn.addEventListener(
"click",
()=>{


formSection.style.display =
formSection.style.display === "none"
?
"block"
:
"none";


});


}










/*==============================
        LOAD PRODUCTS
==============================*/


async function loadProducts(){


try{


const snapshot =
await window.db
.collection("products")
.orderBy(
"createdAt",
"desc"
)
.get();




allProducts =
snapshot.docs.map(
doc=>({

id:doc.id,

...doc.data()

})
);



loadCategories();


renderProducts(
allProducts
);



}



catch(error){


console.error(
"Load Products Error:",
error
);


}


}









/*==============================
        CATEGORY LOAD
==============================*/


function loadCategories(){


if(!categoryFilter)
return;



categoryFilter.innerHTML = `

<option value="all">
All Categories
</option>

`;




const categories =
[
...new Set(
allProducts.map(
product=>product.category
)
)
];





categories.forEach(
category=>{


const option =
document.createElement(
"option"
);


option.value =
category;


option.textContent =
category;


categoryFilter
.appendChild(option);


});



}










/*==============================
        RENDER PRODUCTS
==============================*/


function renderProducts(products){


if(!productsList)
return;




productsList.innerHTML="";




if(!products.length){


productsList.innerHTML =

`

<p>
No Products Found
</p>

`;

return;


}






products.forEach(
product=>{



const card =
document.createElement(
"div"
);



card.className =
"admin-card";





card.innerHTML = `


<img

src="${
product.image ||
"../../assets/logos/logo.png"
}"

alt="${product.name}"

>



<h3>
${product.name}
</h3>



<p>
Category:
${product.category}
</p>




<p>
Stock:
${product.stock}
</p>



<strong>
৳${product.price}
</strong>




<div>


<button

class="edit-product-btn"

data-id="${product.id}">

Edit

</button>



<button

class="delete-product-btn"

data-id="${product.id}">

Delete

</button>


</div>



`;





productsList
.appendChild(card);



});



}










/*==============================
        SAVE PRODUCT
==============================*/


if(form){



form.addEventListener(
"submit",
async(e)=>{


e.preventDefault();



try{



const file =
document.querySelector(
"#product-image"
)
.files[0];





let imageURL = "";






if(file){



imageURL =

await window.ImageService
.uploadImage(
file
);



}







const productData = {


name:

document.querySelector(
"#product-name"
)
.value.trim(),



price:

Number(
document.querySelector(
"#product-price"
)
.value
),



category:

document.querySelector(
"#product-category"
)
.value.trim(),



stock:

Number(
document.querySelector(
"#product-stock"
)
.value
),



updatedAt:

new Date()



};






if(imageURL){


productData.image =
imageURL;


}







/* UPDATE PRODUCT */


if(editProductId){



await window.db
.collection("products")
.doc(editProductId)
.update(
productData
);



editProductId = null;



}






/* ADD PRODUCT */


else{



productData.createdAt =
new Date();



await window.db
.collection("products")
.add(
productData
);



}






alert(
"Product Saved Successfully"
);



form.reset();


formSection.style.display =
"none";



loadProducts();



}



catch(error){



console.error(
"Save Product Error:",
error
);



alert(
"Product Save Failed"
);



}



});


}









/*==============================
        EDIT PRODUCT
==============================*/


document.addEventListener(
"click",
async(e)=>{



if(
e.target.classList
.contains(
"edit-product-btn"
)

){



const id =
e.target.dataset.id;





const doc =
await window.db
.collection("products")
.doc(id)
.get();






const product =
doc.data();





editProductId =
id;






document.querySelector(
"#product-name"
)
.value =
product.name || "";




document.querySelector(
"#product-price"
)
.value =
product.price || "";





document.querySelector(
"#product-category"
)
.value =
product.category || "";





document.querySelector(
"#product-stock"
)
.value =
product.stock || "";






formSection.style.display =
"block";



}



});









/*==============================
        DELETE PRODUCT
==============================*/


document.addEventListener(
"click",
async(e)=>{



if(
e.target.classList
.contains(
"delete-product-btn"
)

){



const id =
e.target.dataset.id;





if(
confirm(
"Delete this product?"
)

){



await window.db
.collection("products")
.doc(id)
.delete();




loadProducts();



}



}



});









/*==============================
        FILTER
==============================*/


function filterProducts(){



let filtered =
[...allProducts];





const search =
searchInput?.value
.toLowerCase()
||
"";



const category =
categoryFilter?.value
||
"all";



const stock =
stockFilter?.value
||
"all";






if(search){


filtered =
filtered.filter(
product=>

product.name
.toLowerCase()
.includes(search)

);


}







if(category !== "all"){


filtered =
filtered.filter(
product=>

product.category === category

);


}







if(stock !== "all"){


filtered =
filtered.filter(
product=>{


if(stock==="in")
return product.stock > 5;


if(stock==="low")
return product.stock > 0 &&
product.stock <= 5;


if(stock==="out")
return product.stock <= 0;



});


}





renderProducts(
filtered
);



}










searchInput?.addEventListener(
"input",
filterProducts
);



categoryFilter?.addEventListener(
"change",
filterProducts
);



stockFilter?.addEventListener(
"change",
filterProducts
);






loadProducts();



});
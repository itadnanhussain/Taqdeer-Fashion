/*=========================================================
                TAQDEER FASHION
                AUTH SERVICE
=========================================================*/

"use strict";



/*=========================================
        REGISTER USER
=========================================*/


async function registerUser(
email,
password,
userData
){

try{


const result =
await window.auth
.createUserWithEmailAndPassword(
email,
password
);



const user =
result.user;



await window.db
.collection("users")
.doc(user.uid)
.set({

uid:user.uid,

email:user.email,

name:userData.name || "",

phone:userData.phone || "",

photo:"",

role:"customer",

createdAt:new Date()

});



return user;



}

catch(error){

console.error(
"Register Error:",
error
);

throw error;

}


}







/*=========================================
        LOGIN USER
=========================================*/


async function loginUser(
email,
password
){


try{


const result =
await window.auth
.signInWithEmailAndPassword(
email,
password
);



return result.user;



}


catch(error){


console.error(
"Login Error:",
error
);


throw error;


}


}








/*=========================================
        GOOGLE LOGIN
=========================================*/


async function googleLogin(){


try{


const provider =
new firebase.auth.GoogleAuthProvider();



const result =
await window.auth
.signInWithPopup(
provider
);



const user =
result.user;



const userRef =
window.db
.collection("users")
.doc(user.uid);




const userDoc =
await userRef.get();





if(!userDoc.exists){


await userRef.set({

uid:user.uid,

email:user.email,

name:user.displayName || "",

photo:user.photoURL || "",

role:"customer",

createdAt:new Date()

});


}





return user;



}



catch(error){


console.error(
"Google Login Error:",
error
);


throw error;


}


}








/*=========================================
        LOGOUT
=========================================*/


async function logoutUser(){


await window.auth
.signOut();


}








/*=========================================
        RESET PASSWORD
=========================================*/


async function resetPassword(email){


return await window.auth
.sendPasswordResetEmail(
email
);


}








window.AuthService={


registerUser,

loginUser,

googleLogin,

logoutUser,

resetPassword


};
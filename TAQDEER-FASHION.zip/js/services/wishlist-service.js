/*=========================================================
                TAQDEER FASHION
                WISHLIST SERVICE
=========================================================*/


"use strict";



const WISHLIST_KEY =
"taqdeerWishlist";





/*=========================================
            GET WISHLIST
=========================================*/


function getWishlist(){


    const wishlist =
    localStorage.getItem(
        WISHLIST_KEY
    );



    return wishlist
    ?
    JSON.parse(wishlist)
    :
    [];


}







/*=========================================
            SAVE
=========================================*/


function saveWishlist(items){


    localStorage.setItem(

        WISHLIST_KEY,

        JSON.stringify(items)

    );


}







/*=========================================
            ADD
=========================================*/


function addToWishlist(product){


    const wishlist =
    getWishlist();





    const exists =
    wishlist.find(
        item =>
        item.id === product.id
    );





    if(!exists){


        wishlist.push({

            id:
            product.id,


            name:
            product.name,


            image:
            product.image,


            price:
            product.price,


            category:
            product.category


        });


        saveWishlist(
            wishlist
        );


    }





    return wishlist;


}







/*=========================================
            REMOVE
=========================================*/


function removeFromWishlist(id){


    let wishlist =
    getWishlist();





    wishlist =
    wishlist.filter(

        item =>
        item.id !== id

    );





    saveWishlist(
        wishlist
    );



    return wishlist;


}







/*=========================================
            CHECK
=========================================*/


function isWishlist(id){


    const wishlist =
    getWishlist();



    return wishlist.some(

        item =>
        item.id === id

    );


}







/*=========================================
            CLEAR
=========================================*/


function clearWishlist(){


    localStorage.removeItem(
        WISHLIST_KEY
    );


}







/*=========================================
            EXPORT
=========================================*/


window.WishlistService={


    getWishlist,

    addToWishlist,

    removeFromWishlist,

    isWishlist,

    clearWishlist


};
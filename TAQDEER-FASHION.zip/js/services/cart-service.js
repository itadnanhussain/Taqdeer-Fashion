/*=========================================================
                TAQDEER FASHION
                CART SERVICE
=========================================================*/


"use strict";



const CART_KEY = "taqdeerCart";

const DELIVERY_FEE = 80;





/*=========================================
            GET CART
=========================================*/


function getCart(){


    const cart =
    localStorage.getItem(
        CART_KEY
    );



    return cart
    ?
    JSON.parse(cart)
    :
    [];


}





/*=========================================
            SAVE CART
=========================================*/


function saveCart(cart){


    localStorage.setItem(
        CART_KEY,
        JSON.stringify(cart)
    );


}







/*=========================================
            ADD TO CART
=========================================*/


function addToCart(product){


    const cart =
    getCart();



    const existing =
    cart.find(
        item =>
        item.id === product.id
    );



    if(existing){


        existing.quantity += 1;


    }

    else{


        cart.push({

id:product.id,

name:product.name,

image:product.image,

price:Number(product.price),

quantity:1,

size:product.size || "M"

});


    }



    saveCart(cart);



    return cart;


}







/*=========================================
            REMOVE ITEM
=========================================*/


function removeFromCart(id){


    let cart =
    getCart();



    cart =
    cart.filter(
        item =>
        item.id !== id
    );



    saveCart(cart);



    return cart;


}







/*=========================================
        UPDATE QUANTITY
=========================================*/


function updateQuantity(
id,
quantity
){


    const cart =
    getCart();



    const item =
    cart.find(
        item =>
        item.id === id
    );



    if(item){


        item.quantity =
        Number(quantity);


    }



    saveCart(cart);



    return cart;


}







/*=========================================
            INCREASE
=========================================*/


function increaseQuantity(id){


    const cart =
    getCart();



    const item =
    cart.find(
        item =>
        item.id === id
    );



    if(item){

        item.quantity++;

    }



    saveCart(cart);


    return cart;


}







/*=========================================
            DECREASE
=========================================*/


function decreaseQuantity(id){


    const cart =
    getCart();



    const item =
    cart.find(
        item =>
        item.id === id
    );



    if(item && item.quantity > 1){


        item.quantity--;


    }



    saveCart(cart);



    return cart;


}







/*=========================================
            CLEAR CART
=========================================*/


function clearCart(){


    localStorage.removeItem(
        CART_KEY
    );


}







/*=========================================
            CART TOTAL
=========================================*/


function getCartTotal(){


    const cart =
    getCart();



    return cart.reduce(

        (total,item)=>

        total +
        (
            item.price *
            item.quantity
        ),

        0

    );


}







/*=========================================
            DELIVERY
=========================================*/


function getDeliveryCharge(){


    return getCart().length
    ?
    DELIVERY_FEE
    :
    0;


}







/*=========================================
            GRAND TOTAL
=========================================*/


function getGrandTotal(){


    return (
        getCartTotal()
        +
        getDeliveryCharge()
    );


}







/*=========================================
            EXPORT
=========================================*/


window.CartService={


    getCart,

    addToCart,

    removeFromCart,

    updateQuantity,

    increaseQuantity,

    decreaseQuantity,

    clearCart,

    getCartTotal,

    getDeliveryCharge,

    getGrandTotal


};
/*=========================================================
                TAQDEER FASHION
                PRODUCT SERVICE
=========================================================*/


"use strict";



/*=========================================
            LOAD PRODUCTS
=========================================*/


async function getProducts(){


    try{


        const snapshot =
        await window.db
        .collection("products")
        .get();



        const products =
        snapshot.docs.map(doc=>{


            return {

                id:doc.id,

                ...doc.data()

            };


        });



        return products;



    }

    catch(error){


        console.error(
            "Product loading error:",
            error
        );


        return [];


    }


}





/*=========================================
            GET SINGLE PRODUCT
=========================================*/


async function getProductById(id){


    try{


        const doc =
        await window.db
        .collection("products")
        .doc(id)
        .get();



        if(!doc.exists){

            return null;

        }



        return {


            id:doc.id,

            ...doc.data()


        };



    }

    catch(error){


        console.error(
            "Single product error:",
            error
        );


        return null;


    }


}







/*=========================================
            FILTER PRODUCTS
=========================================*/


function filterProducts(
products,
category
){


    if(category==="all"){

        return products;

    }



    return products.filter(
        product=>
        product.category===category
    );


}







/*=========================================
            SORT PRODUCTS
=========================================*/


function sortProducts(
products,
type
){


    const sorted =
    [...products];



    if(type==="low-high"){


        return sorted.sort(
            (a,b)=>
            a.price-b.price
        );


    }



    if(type==="high-low"){


        return sorted.sort(
            (a,b)=>
            b.price-a.price
        );


    }



    return sorted;


}







/*=========================================
            GLOBAL EXPORT
=========================================*/


window.ProductService={


    getProducts,

    getProductById,

    filterProducts,

    sortProducts


};